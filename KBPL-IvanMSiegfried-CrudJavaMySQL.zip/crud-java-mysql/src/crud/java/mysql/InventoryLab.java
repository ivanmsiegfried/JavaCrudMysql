/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crud.java.mysql;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;



/**
 *
 * @author Ivan Muhammad Siegfried (41155055210056)
 */

public class InventoryLab {
    static final String DRIVER_JDBC = "com.mysql.cj.jdbc.Driver"; // Driver untuk menghubungkan java dengan database mysql
    static final String DB_URL = "jdbc:mysql://localhost/labeldas"; // Alamat database di localhost
    static final String USERNAME = "root"; // Username untuk Database
    static final String PASSWORD = ""; // Password untuk mengakses Database
    
    // Deklarasi Variabel
    static Connection conn; 
    static Statement stmt; 
    static ResultSet results; 
    
    // Instansiasi Objek
    static InputStreamReader inputStreamReader = new InputStreamReader(System.in);
    static BufferedReader input = new BufferedReader(inputStreamReader);
    
    
    public static void main(String[] args) {
        try{
            Class.forName(DRIVER_JDBC); // Mengasosiasikan kelas dengan Driver JDBC
            
            conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            stmt = conn.createStatement();
            
            while(!conn.isClosed()){
                menuUtama();
            }
            
            stmt.close();
            conn.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    static void menuUtama(){
        System.out.println(" \n\n\n========== LABORATORIUM ELEKTRONIKA DASAR ========== ");
        System.out.println("==================== MENU UTAMA ==================== ");
        System.out.println("1. Insert (Create) Data");
        System.out.println("2. Show (Read) Data");
        System.out.println("3. Edit (Update) Data");
        System.out.println("4. Delete Data");
        System.out.println("0. Keluar\n");
        System.out.println("");
        System.out.print("PILIHAN> ");
        
        try{
            int pil = Integer.parseInt(input.readLine());
            
            switch (pil){
                case 0:
                    System.exit(0);
                    break;
                case 1:
                    createInventory();
                    break;
                case 2: 
                    readInventory();
                    break;
                case 3:
                    updateInventory();
                    break;
                case 4: 
                    deleteInventory();
                    break;
                default:
                    System.out.println("Pilihan salah!");
            }
        } catch (Exception e) {
                e.printStackTrace();
        }
    }
    
    static void createInventory(){
        
        try{
            // ambil input dari user
            System.out.print("Nama Barang: ");
            String nama_barang = input.readLine().trim();
            System.out.print("Status Barang: ");
            String status_barang = input.readLine().trim();
 
            // query simpan
            String sql = "INSERT INTO inventory (nama_barang, status_barang) VALUE('%s', '%s')";
            sql = String.format(sql, nama_barang, status_barang);

            // simpan buku
            stmt.execute(sql);
    
        } catch (Exception e) {
                e.printStackTrace();
        }
         
    }
    
    static int MAX = 100;
 
    public static int[] sortStrings(String[] arr, int n)
    {
        
        
        int[] idx = new int[n];
        for (int k=0; k<n; k++){
            idx[k] = k;
        }
 
        // Sorting strings using bubble sort
        for (int j = 0; j < n - 1; j++)
        {
            for (int i = j + 1; i < n; i++)
            {
                if (arr[j].compareTo(arr[i]) > 0)
                {
                    String temp = arr[j];
                    int temp2 = idx[j];
                    
                    arr[j] = arr[i];
                    idx[j] = idx[i];
                    
                    arr[i] = temp;
                    idx[i] = temp2;
                }
            }
        }
        return idx;
    }
    
    public static int[] bubbleSort(int arr[])
    {
        int n = arr.length;
        int[] idx = new int[n];
        for (int k=0; k<n; k++){
            idx[k] = k;
        }
        
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (arr[j] > arr[j + 1]) {
                    // swap arr[j+1] and arr[j]
                    int temp = arr[j];
                    int temp2 = idx[j];
                    
                    arr[j] = arr[j + 1];
                    idx[j] = idx[j+1];
                    
                    arr[j + 1] = temp;
                    idx[j+1] = temp2;
                    
                }
        
        return idx;
    }
    
    
    static void readInventory(){
        int count = 0 ;
        String sql = "SELECT COUNT(*) as remaining FROM inventory";
        try{
            
            results = stmt.executeQuery(sql);
            if (results.next()) { // just in case
                count = results.getInt("remaining"); // note that indexes are one-based
                //System.out.println(count);
            }
        } catch (Exception e) {
                e.printStackTrace();
        }        
        int i = 0;
        

        
        int[] id_barang = new int[count];
        String[] nama_barang = new String[count];
        String[] status_barang = new String[count];
        sql = "SELECT * FROM inventory";
        try{
            System.out.println("+--------------------------------+");
            System.out.println("| DATA INVENTORY DI LABORATORIUM |");
            System.out.println("+--------------------------------+");
            results = stmt.executeQuery(sql);
            while (results.next()) {
                //int id_barang = results.getInt("id_barang");
                //String nama_barang = results.getString("nama_barang");
                //String status_barang = results.getString("status_barang");
                
                id_barang[i] = results.getInt("id_barang");
                nama_barang[i] = results.getString("nama_barang");
                status_barang[i] = results.getString("status_barang");
                
                //System.out.println(String.format("%d. %s -- Status: %s", id_barang,nama_barang,status_barang));         
                i = i + 1;
            }
            
        System.out.println(" \n\n\n========== LABORATORIUM ELEKTRONIKA DASAR ========== ");
        System.out.println("==================== SORTING DATA ==================== ");
        System.out.println("1. By ID");
        System.out.println("2. By Nama Barang");
        System.out.println("3. By Status Barang");
        System.out.println("0. Keluar\n");
        System.out.println("\n");
        System.out.print("PILIHAN> ");
        
        try{
            int pil = Integer.parseInt(input.readLine());
            int n;
            int[] a;
            switch (pil){
                case 0:
                    System.exit(0);
                    break;
                case 1:
                    n = id_barang.length;
                    a = bubbleSort(id_barang);
                    System.out.println("Strings in sorted order (BY ID) are : ");
                    for (int j = 0; j < n; j++)
                        System.out.println(String.format("%d. %s -- Status: %s", id_barang[j],nama_barang[a[j]],status_barang[a[j]]));        
                    break;
                case 2: 
                    n = nama_barang.length;
                    a = sortStrings(nama_barang, n);
                    System.out.println("Strings in sorted order (BY NAMA_BARANG) are : ");
                    for (int j = 0; j < n; j++){
                        System.out.println(String.format("%d. %s -- Status: %s", id_barang[a[j]],nama_barang[j],status_barang[a[j]]));    
                    }
                    break;
                case 3:
                    n = status_barang.length;
                    a = sortStrings(status_barang, n);
                    System.out.println("Strings in sorted order (BY STATUS_BARANG) are : ");
                    for (int j = 0; j < n; j++){
                        System.out.println(String.format("%d. %s -- Status: %s", id_barang[a[j]],nama_barang[a[j]],status_barang[j]));        
                    }
                    break;
                default:
                    System.out.println("Pilihan salah!");
            }
        } catch (Exception e) {
                e.printStackTrace();
        }        
        
    
        } catch (Exception e) {
                e.printStackTrace();
        }
         
    }
    
    static void updateInventory() {
        try {
            // ambil input dari user
            System.out.print("ID yang ingin anda edit: ");
            int id_barang = Integer.parseInt(input.readLine());
            System.out.print("Nama Barang: ");
            String nama_barang = input.readLine().trim();
            System.out.print("Status Barang: ");
            String status_barang = input.readLine().trim();

            // query update
            String sql = "UPDATE inventory SET nama_barang='%s', status_barang='%s' WHERE id_barang=%d";
            sql = String.format(sql, nama_barang, status_barang, id_barang);

            // update data buku
            stmt.execute(sql);

            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }  
    
    static void deleteInventory(){
        try{
            // ambil input dari user
            System.out.print("ID barang yang ingin anda hapus: ");
            int id_barang = Integer.parseInt(input.readLine());
            
            // buat query hapus
            String sql = String.format("DELETE FROM inventory WHERE id_barang=%d", id_barang);

            // hapus data
            stmt.execute(sql);
            
            System.out.println("Data telah terhapus...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    

    
    
}   
